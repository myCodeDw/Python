from distutils.core import setup

setup(
                name            = 'neste',
                version         = '1.3.0',
                py_modules      = ['nester'],
                author          = 'hfpython',
                author_email    = 'hfpython@headfirstlabs.com',
                url             = 'http://www.headfirstlabs.com',
                description     = 'A simple printer of nested lists',

            )
